BoBo 夏日快乐小狗约会邀请函｜使用说明

本版已经完成：
1. 天水蓝 + 青草绿为大面积主色，柠檬黄约 10% 点缀。
2. 已使用你提供的线条马尔济斯小狗图片。
3. 已放入你提供的背景音乐，点击网页右上角“播放音乐”即可播放。
4. Web3Forms Access Key 已配置，提交结果会发送到该 Key 绑定的邮箱。
5. 南京、食物选项、约会项目、其他想法均已保留。

一、在电脑上测试
1. 先把整个压缩包解压。
2. 打开解压后的 bobo-date-invitation 文件夹。
3. 双击 index.html。
4. 点击右上角音乐按钮测试音乐。
5. 完整填写一次，点击“确认赴约！”。
6. 去 Web3Forms 后台或 Gmail 检查是否收到。

二、文件说明
index.html：网页入口。
styles.css：颜色、布局、按钮、手机适配。
app.js：文案、选项、提交邮箱逻辑。
assets/maltese-line-dog.png：你提供的线条小狗素材。
assets/music.mp3：你提供的背景音乐。

三、发布到 GitHub Pages
1. 注册并登录 GitHub。
2. 点击右上角 +，选择 New repository。
3. 仓库名填写 bobo-date-invitation，选择 Public，创建仓库。
4. 点击 uploading an existing file。
5. 把 bobo-date-invitation 文件夹里面的所有文件拖入上传区域。
   注意：上传 index.html、styles.css、app.js、README 和 assets 文件夹，不能只上传外层文件夹。
6. 点击 Commit changes。
7. 进入仓库 Settings → Pages。
8. Source 选择 Deploy from a branch。
9. Branch 选择 main，目录选择 / (root)，点击 Save。
10. 等待约 1—3 分钟，页面会显示公开网址。

四、重要提醒
1. 手机浏览器通常禁止网页自动播放音乐，所以访问者需要主动点击右上角音乐按钮。
2. Web3Forms Access Key 会存在网页源码中，这是该服务静态网页提交方式的正常形式；不要在代码中写 Gmail 密码或授权码。
3. 背景音乐由你提供，请仅用于你拥有合法使用权的场景。
